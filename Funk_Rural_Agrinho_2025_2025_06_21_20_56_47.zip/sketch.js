let musicaInicio, musicaLevel1, musicaCredito;
let fontRegular;
let logo;
let cenarioInicio;
let fundoEstrada;
let spriteFazendeiro;
let spriteSonic;
let fundoPalco;
let clicouAgora = false;

let mostrandoInstrucoes = true;
let tempoInicioInstrucoes;
let mostrandoContador = false;
let tempoUltimoContador;
let contador = 3;
let mostrarJa = false;
let alertaMostrado = false;

let setas = [];
let teclas = ["⬅️", "⬆️", "➡️", "⬇️"];
let tempoUltimaSeta = 0;
let intervaloSetas = 400;
let totalSetas = 0;
let pontosSonic = 0;
let setasAcertadas = 0;
let faseSonicTerminada = false;
let setasCaindo = false;
let posicoesSetas = [360, 400, 440, 480];
let posicoesSetasFazendeiro = [120, 160, 200, 240];

let setasFazendeiro = [];
let totalSetasFazendeiro = 0;
let maxSetasFazendeiro = 100;
let pontuacaoFazendeiro = 0;
let tempoUltimaSetaFazendeiro = 0;
let faseFazendeiroIniciada = false;
let faseFazendeiroTerminada = false;
let botaoRecomecar;

let imgFestaVitoria;
let imgFazendeiroCaminhao;
let mostrarBalãoVitoria = true;
let textoVitoria = [
  "Nossa, foi demais essa batalha!",
  "Adorei dançar e mostrar meu ritmo.",
  "Agora é hora de seguir para o Ceasa!",
];
let caractereAtualVitoria = 0;
let linhaAtualVitoria = 0;
let tempoUltimoCharVitoria = 0;

class Seta {
  constructor(tipo, x) {
    this.tipo = tipo;
    this.x = x;
    this.y = -30;
    this.velocidade = 3;
    this.foiContada = false;
  }

  atualizar() {
    this.y += this.velocidade;
  }

  mostrar() {
    textAlign(CENTER, CENTER);
    textSize(32);
    text(this.tipo, this.x, this.y);
  }

  chegouNoAlvo() {
    return this.y > height - 80 && this.y < height - 40;
  }
}

function preload() {
  fontRegular = loadFont("PressStart2P-Regular.ttf");
  logo = loadImage("logo.png"); //Prompt no chat gpt: Crie um logo para o meu jogo chamado Funk Rural
  cenarioInicio = loadImage("cenario-inicio.png"); //Prompt no chat gpt: Crie um ceário de um fazenda em clima de festa tamanho 600 por 400 para p5.js
  fundoAboboras = loadImage("aboboras.png"); //Prompt no chat gpt: Crie uma plantação de abóboras pixel art estilo 600 por 400 para p5.js
  imgCaminhao = loadImage("caminhao.png"); //Prompt no chat gpt: Crie uma imagem de um caminhão de lado com um fazendeiro no volante estilo pixel art
  fundoEstrada = loadImage("estrada.png"); //Prompt no chat gpt: Crie um cenário de uma estrada horizontal em pixel art 600 por 400
  fundoFesta = loadImage("festa.png"); //Prompt no chat gpt: Crie uma imagem de uma festa em beira de estrada em pixel art
  spriteFazendeiro = loadImage("fazendeiro.png"); // 2x2 Prompt no chat gpt: Crie um spritesheet em pixel art de um fazendeiro dançando
  spriteSonic = loadImage("sonic.png"); // 2x6
  fundoPalco = loadImage("palco.png"); //Prompt no hat gpt: Crie uma imagem de um palco de beira de estrada a noite em pixel art
  imgFestaVitoria = loadImage("festa_vitoria.png"); //Prompt no chat gpt: Crie uma imagem de fundo de uma festa beira de estrada de noite, com varias pessoa e animais, 600 por 400, em pixel art
  imgFazendeiroCaminhao = loadImage("fazendeiro_caminhao.png"); //Prompt no chat gpt: junte esse fazendeiro e esse caminhão na mesma imagem pixel art png transparente
}

let estadoDoJogo = "introducao";
let textoLore = [
  "Num cantinho do Paraná, Agudos do Sul é o lugar,",
  "onde um fazendeiro sonha alto, querendo se apresentar.",
  "Com abóboras no caminhão e um chapéu bem estiloso,",
  "ele segue rumo ao Ceasa, num desfile fabuloso!",
  "",
  "Mas o caminho até a cidade não será só direção...",
  "Tem festa, tem batida, tem batalha e improvisação!",
  "Cada parada é uma rima, um duelo de dançarino,",
  "e ele só segue viagem se mostrar seu dom divino.",
  "",
  "Do campo à capital, com coragem e melodia,",
  "ele espalha alegria com seu ritmo e harmonia.",
  "Prepare-se, aventureiro, para esse som original...",
  "começa agora o desafio chamado: Funk Rural!",
];
let textoCutscene = "Hora de levar essas abóboras pro Ceasa de Curitiba!";
let caracteresCutscene = 0;
let tempoUltimoCharCutscene = 0;
let mostrarBalão = true;
let fundoAboboras;
let botaoPular;

let imgCaminhao;
let posXcaminhao;
let posXPoeira = 0;
let posYPoeira = 0;

let fundoFesta;
let textoCutscene3 =
  "Durante o caminho, o caminhoneiro encontrou uma festa na beira da estrada... e decidiu participar de uma batalha de breaking e rap!";
let caracteresCutscene3 = 0;
let tempoUltimoCharCutscene3 = 0;

let linhaAtual = 0;
let caracteresMostrados = 0;
let tempoUltimoChar = 0;

function mostrarIntroducao() {
  botaoPular.show();
  background(0);
  fill(255);
  textFont(fontRegular);
  textAlign(CENTER);
  textSize(11);

  let linha = textoLore[linhaAtual];

  if (millis() - tempoUltimoChar > 40 && caracteresMostrados < linha.length) {
    caracteresMostrados++;
    tempoUltimoChar = millis();
  }

  for (let i = 0; i < linhaAtual; i++) {
    text(textoLore[i], width / 2, 50 + i * 25);
  }

  text(
    linha.substring(0, caracteresMostrados),
    width / 2,
    50 + linhaAtual * 25
  );

  if (caracteresMostrados >= linha.length && millis() - tempoUltimoChar > 800) {
    if (linhaAtual < textoLore.length - 1) {
      linhaAtual++;
      caracteresMostrados = 0;
      tempoUltimoChar = millis();
    } else {
      estadoDoJogo = "telaInicio";
      botaoPular.hide();
    }
  }
}

function setup() {
  createCanvas(600, 400);
  musicaInicio = document.getElementById("musicaInicio");
  musicaLevel1 = document.getElementById("musicaLevel1");
  musicaCredito = document.getElementById("musicaCredito");
  musicaInicio.volume = 1.0;
  musicaLevel1.volume = 1.0;
  musicaCredito.volume = 1.0;
  musicaInicio.play();

  posXcaminhao = width;
  botaoPular = createButton("Pular Introdução");
  botaoPular.position(width - 140, 1);
  botaoPular.size(120, 30);
  botaoPular.mousePressed(() => {
    estadoDoJogo = "telaInicio";
    botaoPular.hide();
    clicouAgora = true;
  });
  botaoPular.hide();

  mostrandoInstrucoes = true;
  tempoInicioInstrucoes = millis();
  mostrandoContador = false;
  mostrarJa = false;

  botaoRecomecar = createButton("Recomeçar");
  botaoRecomecar.position(width / 2 - 60, height - 60);
  botaoRecomecar.size(120, 30);
  botaoRecomecar.mousePressed(() => {
    reiniciarJogo();
  });
  botaoRecomecar.hide();
}

function draw() {
  if (estadoDoJogo !== "introducao") {
    botaoPular.hide();
  }
  if (estadoDoJogo === "introducao") {
    background(0);
    mostrarIntroducao();
  } else if (estadoDoJogo === "telaInicio") {
    background(50, 150, 50);
    mostrarTelaInicio();
  } else if (estadoDoJogo === "cutscene") {
    mostrarCutscene();
  } else if (estadoDoJogo === "cutscene2") {
    mostrarCutscene2();
  } else if (estadoDoJogo === "cutscene3") {
    mostrarCutscene3();
  } else if (estadoDoJogo === "level1") {
    mostrarLevel1();
  } else if (estadoDoJogo === "gameover") {
    mostrarGameOver();
  } else if (estadoDoJogo === "empate") {
    mostrarEmpate();
  } else if (estadoDoJogo === "cutsceneVitoria") {
    mostrarCutsceneVitoria();
  } else if (estadoDoJogo === "creditos") {
    mostrarCreditos();
  }
}

function mostrarTelaInicio() {
  imageMode(CORNER);
  image(cenarioInicio, 0, 0, width, height);
  imageMode(CENTER);
  image(logo, width / 2, height / 2 - 100, 300, 150);

  fill(255);
  textFont(fontRegular);
  textAlign(CENTER);
  textSize(20);
  text("Clique para começar", width / 2, height / 2 + 80);
}

function mousePressed() {
  if (clicouAgora) {
    clicouAgora = false;
    return;
  }
  if (estadoDoJogo === "telaInicio") {
    estadoDoJogo = "cutscene";
  } else if (estadoDoJogo === "cutscene") {
    mostrarBalão = false;
    estadoDoJogo = "cutscene2";
  } else if (estadoDoJogo === "cutscene2") {
    estadoDoJogo = "cutscene3";
  }
}

function jogar() {
  //Apenas para organização
  background(0);
  fill(255);
  textAlign(CENTER);
  textSize(24);
  text("O jogo começou!", width / 2, height / 2);
}

function mostrarCutscene() {
  background(0);
  imageMode(CORNER);
  image(fundoAboboras, 0, 0, width, height);

  if (mostrarBalão) {
    fill(255);
    stroke(0);
    strokeWeight(3);
    rectMode(CENTER);
    rect(width / 2, height / 2 - 50, 460, 80, 10);

    if (
      millis() - tempoUltimoCharCutscene > 40 &&
      caracteresCutscene < textoCutscene.length
    ) {
      caracteresCutscene++;
      tempoUltimoCharCutscene = millis();
    }

    fill(0);
    noStroke();
    textFont(fontRegular);
    textSize(10);
    textAlign(CENTER, CENTER);
    text(
      textoCutscene.substring(0, caracteresCutscene),
      width / 2,
      height / 2 - 50,
      440,
      70
    );
  }
}

function mostrarCutscene2() {
  background(0);
  imageMode(CORNER);
  image(fundoEstrada, 0, 0, width, height);
  image(imgCaminhao, posXcaminhao, height - 150, 200, 100);

  posXcaminhao -= 2;

  posXPoeira = posXcaminhao + 150;
  posYPoeira = height - 80;

  noStroke();
  fill(200, 200, 200, 100);
  ellipse(posXPoeira, posYPoeira, 30, 20);
  ellipse(posXPoeira + 10, posYPoeira + 5, 25, 15);
  ellipse(posXPoeira - 10, posYPoeira + 5, 25, 15);

  if (posXcaminhao < -200) {
    estadoDoJogo = "cutscene3";
  }
}

function mostrarCutscene3() {
  background(0);
  imageMode(CORNER);
  image(fundoFesta, 0, 0, width, height);

  fill(255);
  stroke(0);
  strokeWeight(3);
  rectMode(CENTER);
  rect(width / 2, height - 80, 540, 80, 10);

  fill(0);
  noStroke();
  textFont(fontRegular);
  textSize(10);
  textAlign(CENTER, CENTER);

  if (
    millis() - tempoUltimoCharCutscene3 > 40 &&
    caracteresCutscene3 < textoCutscene3.length
  ) {
    caracteresCutscene3++;
    tempoUltimoCharCutscene3 = millis();
  }

  text(
    textoCutscene3.substring(0, caracteresCutscene3),
    width / 2,
    height - 80,
    500,
    70
  );

  if (caracteresCutscene3 >= textoCutscene3.length) {
    // Espera 2 segundos e vai para o level 1
    setTimeout(() => {
      musicaInicio.pause();
      musicaInicio.currentTime = 0;
      musicaLevel1.play();

      estadoDoJogo = "level1";
    }, 2000);
  }
}

let frameFaz = 0;
let frameSonic = 0;
let tempoUltimoFrameFaz = 0;
let tempoUltimoFrameSonic = 0;

let totalSetasCaindo = 0;
let maxSetas = 100;
let pontuacaoSonic = 0;
let setasSonic = [];
let tempoUltimaSetaCriada = 0;
let intervaloCriarSeta = 500;
let velocidadeSeta = 8;
let limiteSetasNaTela = 8;

function keyPressed() {
  if (!faseFazendeiroIniciada || faseFazendeiroTerminada) return;

  for (let i = 0; i < setasFazendeiro.length; i++) {
    let seta = setasFazendeiro[i];
    if (
      !seta.acertada &&
      seta.y >= height - 120 &&
      seta.y <= height - 20 &&
      key === seta.teclaEsperada
    ) {
      pontuacaoFazendeiro++;
      console.log("ACERTOU! Pontuação atual:", pontuacaoFazendeiro);
      seta.acertada = true;
      setasFazendeiro.splice(i, 1);
      break;
    }
  }
}

function criarSetaSonic() {
  if (totalSetasCaindo >= maxSetas || setasSonic.length >= limiteSetasNaTela)
    return;

  let col = floor(random(4));
  let x = posicoesSetas[col];
  let y = -40;
  let tipo = ["⬅️", "⬆️", "➡️", "⬇️"][col];
  setasSonic.push({ x, y, tipo, col, acertada: false });
  totalSetasCaindo++;
}

function atualizarSetasSonic() {
  for (let i = setasSonic.length - 1; i >= 0; i--) {
    let seta = setasSonic[i];
    seta.y += velocidadeSeta;
    textSize(32);
    textAlign(CENTER, CENTER);
    text(seta.tipo, seta.x, seta.y);

    let yPlataforma = height - 60;
    if (
      !seta.acertada &&
      seta.y >= yPlataforma - 10 &&
      seta.y <= yPlataforma + 10
    ) {
      seta.acertada = true;
      if (pontuacaoSonic < 79) {
        pontuacaoSonic++;
      }
    }
    if (seta.y > height - 60) {
      setasSonic.splice(i, 1);
    }
  }
}

function criarSetaFazendeiro() {
  if (
    totalSetasFazendeiro >= maxSetasFazendeiro ||
    setasFazendeiro.length >= limiteSetasNaTela
  )
    return;

  let col = floor(random(4));
  let x = posicoesSetasFazendeiro[col];
  let tipo = teclas[col];
  let tecla = ["ArrowLeft", "ArrowUp", "ArrowRight", "ArrowDown"][col];

  setasFazendeiro.push({
    x,
    y: -40,
    tipo,
    col,
    acertada: false,
    teclaEsperada: tecla,
  });

  totalSetasFazendeiro++;
}

function atualizarSetasFazendeiro() {
  for (let i = setasFazendeiro.length - 1; i >= 0; i--) {
    let seta = setasFazendeiro[i];
    seta.y += velocidadeSeta;
    textSize(32);
    textAlign(CENTER, CENTER);
    text(seta.tipo, seta.x, seta.y);

    if (seta.y > height - 35) {
      setasFazendeiro.splice(i, 1);
    }
  }
}

function mostrarLevel1() {
  background(0);
  imageMode(CORNER);
  image(fundoPalco, 0, 0, width, height);

  // Fazendeiro
  let quadrosFaz = 4;
  let colFaz = 2;
  let frameWidthFaz = spriteFazendeiro.width / colFaz;
  let frameHeightFaz = spriteFazendeiro.height / 2;

  if (millis() - tempoUltimoFrameFaz > 200) {
    frameFaz = (frameFaz + 1) % quadrosFaz;
    tempoUltimoFrameFaz = millis();
  }

  let linhaFaz = floor(frameFaz / colFaz);
  let colunaFaz = frameFaz % colFaz;
  let escalaFaz = 0.4;
  let destinoLarguraFaz = frameWidthFaz * escalaFaz;
  let destinoAlturaFaz = frameHeightFaz * escalaFaz;
  let posXFaz = 150;
  let posYFaz = height - destinoAlturaFaz - 130;

  image(
    spriteFazendeiro,
    posXFaz,
    posYFaz,
    destinoLarguraFaz,
    destinoAlturaFaz,
    colunaFaz * frameWidthFaz,
    linhaFaz * frameHeightFaz,
    frameWidthFaz,
    frameHeightFaz
  );

  // Sonic
  let quadrosSonic = 12;
  let colSonic = 6;
  let frameWidthSonic = spriteSonic.width / colSonic;
  let frameHeightSonic = spriteSonic.height / 2;

  if (millis() - tempoUltimoFrameSonic > 120) {
    frameSonic = (frameSonic + 1) % quadrosSonic;
    tempoUltimoFrameSonic = millis();
  }

  let linhaSonic = floor(frameSonic / colSonic);
  let colunaSonic = frameSonic % colSonic;

  image(
    spriteSonic,
    width - 220,
    height - frameHeightSonic - 130,
    frameWidthSonic,
    frameHeightSonic,
    colunaSonic * frameWidthSonic,
    linhaSonic * frameHeightSonic,
    frameWidthSonic,
    frameHeightSonic
  );

  if (!alertaMostrado) {
    alert(
      "100 setas irão cair.\nSupere a pontuação do adversário para vencer!"
    );
    alertaMostrado = true;
    mostrandoContador = true;
    tempoUltimoContador = millis();
    contador = 3;
  }

  if (mostrandoInstrucoes) {
    if (millis() - tempoInicioInstrucoes < 3000) {
    } else {
      mostrandoInstrucoes = false;
      mostrandoContador = true;
      tempoUltimoContador = millis();
      contador = 3;
    }
  }

  if (mostrandoContador) {
    if (millis() - tempoUltimoContador > 1000) {
      contador--;
      tempoUltimoContador = millis();

      if (contador < 0) {
        mostrandoContador = false;
        mostrarJa = true;
        tempoUltimoContador = millis();
      }
    }

    if (contador > 0) {
      fill(0, 200);
      noStroke();
      rectMode(CENTER);
      rect(width / 2, height / 2 + 30, 100, 60, 10);

      fill(255);
      textFont(fontRegular);
      textSize(32);
      textAlign(CENTER, CENTER);
      text(contador, width / 2, height / 2 + 30);
    }
  }

  if (mostrarJa) {
    if (millis() - tempoUltimoContador < 1000) {
      fill(0, 200);
      noStroke();
      rectMode(CENTER);
      rect(width / 2, height / 2 + 30, 100, 60, 10);

      fill(255);
      textFont(fontRegular);
      textSize(28);
      textAlign(CENTER, CENTER);
      text("Já!", width / 2, height / 2 + 30);
    } else {
      mostrarJa = false;
      setasCaindo = true;
    }
  }

  if (setasCaindo && !faseSonicTerminada) {
    fill(0, 180);
    rectMode(CENTER);
    rect(width / 2, 30, 120, 30, 8);

    fill(255);
    textFont(fontRegular);
    textSize(10);
    textAlign(CENTER, CENTER);
    text("Sonic: " + pontuacaoSonic + " pts", width / 2, 30);

    for (let i = 0; i < 4; i++) {
      let x = posicoesSetas[i];
      fill(100, 100, 100);
      rect(x, height - 60, 50, 50, 10);
      fill(255);
      textSize(24);
      textAlign(CENTER, CENTER);
      text(["⬅️", "⬆️", "➡️", "⬇️"][i], x, height - 60);
    }

    if (millis() - tempoUltimaSetaCriada > intervaloCriarSeta) {
      criarSetaSonic();
      tempoUltimaSetaCriada = millis();
    }
    atualizarSetasSonic();

    if (totalSetasCaindo >= maxSetas && setasSonic.length === 0) {
      faseSonicTerminada = true;
      setasCaindo = false;
      faseFazendeiroIniciada = true;
      tempoUltimaSetaFazendeiro = millis();
    }
  }

  if (faseSonicTerminada && !faseFazendeiroTerminada) {
    if (!faseFazendeiroIniciada) {
      faseFazendeiroIniciada = true;
      tempoUltimaSetaFazendeiro = millis();
    }
    fill(0, 180);
    rectMode(CENTER);
    rect(width / 2, 30, 140, 30, 8);

    fill(255);
    textFont(fontRegular);
    textSize(10);
    textAlign(CENTER, CENTER);
    text("Fazendeiro: " + pontuacaoFazendeiro + " pts", width / 2, 30);

    for (let i = 0; i < 4; i++) {
      let x = posicoesSetasFazendeiro[i];
      fill(100, 100, 100);
      rect(x, height - 60, 50, 50, 10);
      fill(255);
      textSize(24);
      text(teclas[i], x, height - 60);
    }

    if (millis() - tempoUltimaSetaFazendeiro > intervaloCriarSeta) {
      criarSetaFazendeiro();
      tempoUltimaSetaFazendeiro = millis();
    }

    atualizarSetasFazendeiro();

    if (
      totalSetasFazendeiro >= maxSetasFazendeiro &&
      setasFazendeiro.length === 0
    ) {
      faseFazendeiroTerminada = true;
      console.log("Fase do fazendeiro finalizada");
      if (pontuacaoFazendeiro > 79) {
        estadoDoJogo = "cutsceneVitoria";
        linhaAtualVitoria = 0;
        caractereAtualVitoria = 0;
        tempoUltimoCharVitoria = millis();
        mostrarBalãoVitoria = true;
      }
    }
  }

  if (
    totalSetasFazendeiro >= maxSetasFazendeiro &&
    setasFazendeiro.length === 0
  ) {
    faseFazendeiroTerminada = true;

    if (pontuacaoFazendeiro < pontuacaoSonic) {
      estadoDoJogo = "gameover";
    } else if (pontuacaoFazendeiro === pontuacaoSonic) {
      estadoDoJogo = "empate";
    } else {
      estadoDoJogo = "cutsceneVitoria";
    }
  }
}

function mostrarGameOver() {
  background(0);
  fill(255, 0, 0);
  textFont(fontRegular);
  textAlign(CENTER, CENTER);
  textSize(28);
  text("GAME OVER", width / 2, height / 2 - 20);
  textSize(12);
  text("Você perdeu o duelo contra o Sonic...", width / 2, height / 2 + 20);
  botaoRecomecar.show();
}

function mostrarEmpate() {
  background(30);
  fill(255, 255, 0);
  textFont(fontRegular);
  textAlign(CENTER, CENTER);
  textSize(28);
  text("EMPATE!", width / 2, height / 2 - 20);
  textSize(12);
  text("Foi uma batalha acirrada, ninguém venceu.", width / 2, height / 2 + 20);
  botaoRecomecar.show();
}

function reiniciarJogo() {
  estadoDoJogo = "introducao";
  linhaAtual = 0;
  caracteresMostrados = 0;
  tempoUltimoChar = 0;
  faseFazendeiroTerminada = false;
  faseSonicTerminada = false;
  faseFazendeiroIniciada = false;
  setasSonic = [];
  setasFazendeiro = [];
  pontuacaoSonic = 0;
  pontuacaoFazendeiro = 0;
  totalSetasCaindo = 0;
  totalSetasFazendeiro = 0;
  mostrarJa = false;
  mostrandoInstrucoes = true;
  alertaMostrado = false;
  botaoRecomecar.hide();
}

function mostrarCutsceneVitoria() {
  background(0);
  imageMode(CORNER);
  image(imgFestaVitoria, 0, 0, width, height);

  fill(255, 215, 0);
  textFont(fontRegular);
  textSize(48);
  textAlign(CENTER, CENTER);
  text("VITÓRIA", width / 2, 60);

  let escalaCaminhao = 0.1;
  let larguraCaminhao = imgFazendeiroCaminhao.width * escalaCaminhao;
  let alturaCaminhao = imgFazendeiroCaminhao.height * escalaCaminhao;
  image(
    imgFazendeiroCaminhao,
    width / 2 - larguraCaminhao / 2,
    height - alturaCaminhao - 50,
    larguraCaminhao,
    alturaCaminhao
  );

  if (mostrarBalãoVitoria) {
    fill(255);
    stroke(0);
    strokeWeight(3);
    rectMode(CENTER);
    let balaoX = width / 2;
    let balaoY = height / 2 - 40;
    let balaoW = 400;
    let balaoH = 100;
    rect(balaoX, balaoY, balaoW, balaoH, 10);

    fill(0);
    noStroke();
    textFont(fontRegular);
    textSize(14);
    textAlign(CENTER, CENTER);

    if (
      millis() - tempoUltimoCharVitoria > 40 &&
      caractereAtualVitoria < textoVitoria[linhaAtualVitoria].length
    ) {
      caractereAtualVitoria++;
      tempoUltimoCharVitoria = millis();
    }

    let textoAtual = textoVitoria[linhaAtualVitoria].substring(
      0,
      caractereAtualVitoria
    );
    text(textoAtual, balaoX, balaoY, balaoW - 40, balaoH - 20);

    if (caractereAtualVitoria >= textoVitoria[linhaAtualVitoria].length) {
      if (millis() - tempoUltimoCharVitoria > 800) {
        if (linhaAtualVitoria < textoVitoria.length - 1) {
          linhaAtualVitoria++;
          caractereAtualVitoria = 0;
          tempoUltimoCharVitoria = millis();
        } else {
          setTimeout(() => {
            estadoDoJogo = "creditos";
          }, 5000);
        }
      }
    }
  }
}

let scrollY = 400;

function mostrarCreditos() {
  background(0);
  fill(255);
  textAlign(CENTER, CENTER);
  textFont(fontRegular);
  textSize(14);

  if (!musicaCredito.creditsTocando) {
    musicaInicio.pause();
    musicaLevel1.pause();

    musicaCredito.currentTime = 0;
    musicaCredito.play();
    musicaCredito.creditsTocando = true;
  }

  let creditText = [
    "VITÓRIA!",
    "",
    "Créditos:",
    "",
    "Jogo criado por:",
    "Henrique Carnelossi Godoy",
    "",
    "Imagens e sprites criados por:",
    "ChatGPT (OpenAI)",
    "Sprite do Sonic por artista do DeviantArt",
    "",
    "Músicas:",
    "Introdução: 'Splashing Around'",
    "The Green Orbs",
    "",
    "Desafio: 'Dança da Roça'",
    "DJ Chris no Beat e João Dalzoto",
    "",
    "Créditos: 'What I've Done'",
    "Linkin Park",
    "",
    "Agradecimentos especiais:",
    "Professora Dhuly Fabiana",
    "João 14:6: Disse-lhe Jesus:",
    "Eu sou o caminho, a verdade e a vida.",
    "Ninguém vem ao Pai senão por mim.",
    "Obrigado por jogar Funk Rural!",
  ];

  for (let i = 0; i < creditText.length; i++) {
    text(creditText[i], width / 2, scrollY + i * 30);
  }

  scrollY -= 1;

  if (scrollY + creditText.length * 30 < 0) {
    scrollY = height + 50;
  }
}

function voltarAoMenu() {
  musica.pause();
  musica.src = "musica-inicio.mp3";
  musica.load();
  musica.play();
  musica.creditsTocando = false;
  estadoDoJogo = "telaInicio";
}
